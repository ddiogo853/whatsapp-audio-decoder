import { buffer } from 'micro';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Only POST requests allowed' });
  }

  const bufferData = await buffer(req);

  // Aqui você pode aplicar sua lógica de descriptografia
  return res.status(200).json({
    status: 'sucesso',
    message: 'Requisição processada com sucesso!',
    dados: {
      base64: bufferData.toString('base64'),
    },
  });
}
